# Module 5 - Student Starter Code 

# This code is provided as a starting point for the assignment.
# You are expected to complete the code and implement the required functionality. 
# TODO: Import libraries for whatever you need to complete the assignment (the libraries below are for reference and are incomplete).
import numpy as np
import pandas as pd

# Import libraries for visualization from matplotlib and seaborn and inspection from sklearn
import matplotlib.pyplot as plt
import seaborn as sns

# TODO: Import libraries for preprocessing from sklearn
from sklearn.preprocessing import OrdinalEncoder  # Import for preprocessing string data

# Import libraries for imputation from sklearn
from sklearn.impute import SimpleImputer
from sklearn.impute import KNNImputer
from sklearn.experimental import enable_iterative_imputer # Experimental iterative features
from sklearn.impute import IterativeImputer

# Import libraries for model model selection and metrics from sklearn
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline

# Import libraries for regression from sklearn
from sklearn.linear_model import LinearRegression

# Function to test dataset on a linear regression model
# Use this function to compare how different imputation methods affect the model performance
def get_score(df, imputer=None): 

       # Define features (X) and target (y)
    X = df.drop(columns=["Class"])
    y = df["Class"]

    regressor = LinearRegression()
    if imputer is not None:
        estimator = make_pipeline(imputer, regressor)
    else:
        estimator = regressor
    scores = cross_val_score(
        estimator, X, y, scoring="neg_mean_squared_error", cv=4
    )
    return scores.mean(), scores.std()


#----------------------------------------------------------------
# Step 1: Load the CSV file into a pandas DataFrame
#----------------------------------------------------------------
df = pd.read_csv("Module5Dataset.csv")  

#----------------------------------------------------------------
# Step 2: Data Exploration and Visualization
#         Does the data contain NAN or nan values (implying incomplete data)?
#         What type of data is in the dataset?
#----------------------------------------------------------------

# TODO: Display information about the dataset
print(df.info())  # Prints structure, data types, and non-null column counts
print(df.isna().sum())  # Explicitly prints count of missing values per column

# TODO: Dispay the unique values in each feature
for col in df.columns:
    print(f"Unique values in {col}: {df[col].unique()}")  # Loop and print unique entries for each field

# TODO: Visualize the distribution of 'Features'
plt.figure(figsize=(12, 8))  # Initializes figure size for features distribution subplot
for i, col in enumerate(df.columns[:-1], 1):
    plt.subplot(2, 3, i)  # Setup 2x3 grid layout for features
    sns.countplot(data=df, x=col, order=df[col].dropna().unique())  # Displays category breakdown frequency
    plt.title(f"Distribution of {col}")  # Sets individual feature graph titles
plt.tight_layout()  # Adjusts margins automatically
plt.savefig("feature_distributions.png", dpi=300)  # Saves the distribution subplot layout directly as a high-res PNG file
plt.show()


#----------------------------------------------------------------
# Step 3: TODO: Does the dataset work on the linear regression model before preprocessing?
#         TODO: What type of data does the sklearn linear regression model accept?
#----------------------------------------------------------------
# Answer 1: No, it will fail due to string values (categorical values) and missing NaN values.
# Answer 2: Scikit-learn's Linear Regression requires strictly numerical data.

x_labels = []

mses = np.zeros(5) # Kept at 5 to align with your index positions [0, 1, 2, 3, 4]
stds = np.zeros(5) # Kept at 5 to align with your index positions [0, 1, 2, 3, 4]

# Using np.nan keeps a placeholder spot for RAW on the chart without drawing an invisible 0-bar or distorting scales
mses[0], stds[0] = np.nan, np.nan  
x_labels.append("RAW Dataset")

#----------------------------------------------------------------
# Step 4: TODO: Transform the dataset
#         Note: It is possible to impute missing values in the dataset before transforming it.
#               or even at the same time.
#----------------------------------------------------------------
# Mapping dictionaries built based on ordinal relationships present inside the car dataset
mapping_f1_f2 = {"low": 1, "med": 2, "high": 3, "vhigh": 4}
mapping_f3 = {"2": 2, "3": 3, "4": 4, "5more": 5}
mapping_f4 = {"2": 2, "4": 4, "more": 6}
mapping_f5 = {"small": 1, "med": 2, "big": 3}
mapping_f6 = {"low": 1, "med": 2, "high": 3}
mapping_class = {"unacc": 1, "acc": 2, "good": 3, "vgood": 4}

df_transformed = df.copy()  # Creates deep copy of the raw dataframe

# Map the categorical strings to structured ordinal numbers preserving NaNs for explicit imputation later
df_transformed["Feature1"] = df_transformed["Feature1"].map(mapping_f1_f2)  # Encodes feature 1
df_transformed["Feature2"] = df_transformed["Feature2"].map(mapping_f1_f2)  # Encodes feature 2
df_transformed["Feature3"] = df_transformed["Feature3"].map(mapping_f3)     # Encodes feature 3
df_transformed["Feature4"] = df_transformed["Feature4"].map(mapping_f4)     # Encodes feature 4
df_transformed["Feature5"] = df_transformed["Feature5"].map(mapping_f5)     # Encodes feature 5
df_transformed["Feature6"] = df_transformed["Feature6"].map(mapping_f6)     # Encodes feature 6
df_transformed["Class"] = df_transformed["Class"].map(mapping_class)        # Encodes target response column

#----------------------------------------------------------------
# Step 5: TODO: Impute missing values in the dataset (replace NAN or nan values)
#         Experiment with the following imputers: 
#         - SimpleImputer with strategy='constant' and fill_value=0
#         - SimpleImputer with strategy='mean'
#         - KNNImputer
#         - IterativeImputer
#----------------------------------------------------------------

# Example code for documentation only
imputer = SimpleImputer(strategy="constant", fill_value=0)
mses[1], stds[1] = get_score(df_transformed, imputer)  # Run pipeline evaluating constant value approach
x_labels.append("Zero Imputation")

imputer = SimpleImputer(strategy="mean")
mses[2], stds[2] = get_score(df_transformed, imputer)  # Run pipeline evaluating mean calculations strategy
x_labels.append("Mean Imputation")

imputer = KNNImputer()
mses[3], stds[3] = get_score(df_transformed, imputer)  # Run pipeline using nearest neighbor data logic
x_labels.append("KNN Imputation")

imputer = IterativeImputer(max_iter=10, random_state=42)
mses[4], stds[4] = get_score(df_transformed, imputer)  # Run pipeline leveraging predictive features modeling
x_labels.append("Iterative Imputation")


#----------------------------------------------------------------
# Step 6: TODO: Collect data metrics and visualization of:
#         Dataset after transforming
#         Dataset after imputing missing values
#         sns.heatmap(?????????.corr(), annot=True, cmap="coolwarm", fmt=".2f")
#--------------------------------------------------------------------

# Perform explicit single-fit check to generate correlation metrics post-imputation
final_imputer = IterativeImputer(max_iter=10, random_state=42)  # Initialize choice of imputer
imputed_array = final_imputer.fit_transform(df_transformed)  # Converts all remaining data rows into continuous matrices
df_imputed = pd.DataFrame(imputed_array, columns=df.columns)  # Creates dataframe out of final processed figures

print("Dataset Post-Transformation Description Summary:\n", df_transformed.describe())  # Metric metrics extraction
print("\nCorrelation matrix post-imputation evaluation layout:")  # Matrix header string

plt.figure(figsize=(8, 6))  # Setup structural size settings for correlation plot
sns.heatmap(df_imputed.corr(), annot=True, cmap="coolwarm", fmt=".2f")  # Creates relational heatmap graph 
plt.title("Feature Correlation Heatmap After Transformation and Imputation")  # Adds chart descriptor title
plt.savefig("correlation_heatmap.png", dpi=300)  # Saves the generated correlation matrix map as a clean PNG image file
plt.show()

print("Negative Mean Squared Errors (MSEs):", mses)
print("Standard Deviations (STDs):", stds)

# Plot the results
plt.figure(figsize=(10, 6))
plt.bar(x_labels, mses, yerr=stds, capsize=5)  # Correctly maps error metrics to bars
plt.xlabel("Imputation Method")
plt.ylabel("Negative Mean Squared Error")
plt.title("Comparison of Imputation Methods")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("imputation_comparison.png", dpi=300)  # Saves the final analytical bar charts matrix comparison to a PNG image file
plt.show()