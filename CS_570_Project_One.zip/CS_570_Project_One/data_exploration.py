import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load your actual dataset
df = pd.read_csv('ProjectPartOneDataSet.csv') 

print("--- Original Data Sample ---")
print(df.head())

# 2. ENCODING: This transforms the text labels into numbers so we can plot them!
df_encoded = df.copy()
for col in df_encoded.columns:
    df_encoded[col] = df_encoded[col].astype('category').cat.codes

print("\n--- Encoded Data Sample (Now numbers!) ---")
print(df_encoded.head())

# 3. Generate Histograms
df_encoded.hist(bins=5, figsize=(12, 8), edgecolor='black')
plt.suptitle("Feature Category Distributions (Histograms)")
plt.tight_layout()
plt.savefig('histograms.png') 
plt.show()

# 4. Visualize the Correlation Matrix
plt.figure(figsize=(10, 8))
sns.heatmap(df_encoded.corr(), annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Correlation Matrix Heatmap")
plt.tight_layout()
plt.savefig('correlation_matrix.png') 
plt.show()