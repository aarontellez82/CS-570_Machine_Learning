import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV, KFold
from sklearn.preprocessing import OrdinalEncoder, StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                             f1_score, confusion_matrix, cohen_kappa_score, 
                             classification_report)

#Load the dataset
df = pd.read_csv('ProjectPartOneDataSet.csv')

#Preprocessing: Separate features and target
X = df.drop(columns=['class'])
y = df['class']

# Encode the categorical features and target labels properly
encoder_X = OrdinalEncoder()
X_encoded = encoder_X.fit_transform(X)

#Train/Test Split (80% training, 20% validation/testing)
X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42, stratify=y)

# Scale features (Critical for distance-based models like kNN)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

#Set up K-Fold Cross Validation & Grid Search Tuning
kf = KFold(n_splits=5, shuffle=True, random_state=42)
param_grid = {
    'n_neighbors': [3, 5, 7, 9, 11, 13, 15],
    'weights': ['uniform', 'distance'],
    'metric': ['euclidean', 'manhattan']
}

grid_search = GridSearchCV(KNeighborsClassifier(), param_grid, cv=kf, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_scaled, y_train)

#Extract Evaluation Metrics
best_model = grid_search.best_estimator_
y_pred = best_model.predict(X_test_scaled)


print(f" Best Hyperparameters: {grid_search.best_params_}")

#Rubric Metrics
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='macro')
recall = recall_score(y_test, y_pred, average='macro')
f1 = f1_score(y_test, y_pred, average='macro')
kappa = cohen_kappa_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)

print(f"Accuracy:  {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1 Score:  {f1:.4f}")
print(f"Kappa:     {kappa:.4f}\n")

print("Confusion Matrix:")
print(cm)

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

#Evaluate using Plots: Confusion Matrix Visualization
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=best_model.classes_, 
            yticklabels=best_model.classes_)
plt.title('Confusion Matrix - Optimized kNN Model')
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.tight_layout()
plt.savefig('confusion_matrix_knn.png')
plt.show()