import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split, GridSearchCV, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                             f1_score, confusion_matrix, cohen_kappa_score, 
                             classification_report)

#Load the digits dataset
digits = load_digits()
X, y = digits.data, digits.target

print("--- Data Exploration ---")
print(f"Dataset features shape: {X.shape}") # 1797 samples, 64 features (8x8 pixels flattened)
print(f"Target classes: {np.unique(y)}")

#Train and Validation Split
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Scale features (Essential for Multi-Layer Perceptrons to converge properly)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)

#Set up K-Fold Cross Validation and GridSearchCV for Hyperparameter Tuning
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# Grid parameters matching the rubric guidelines
param_grid = {
    'hidden_layer_sizes': [(50,), (100,), (50, 50)],
    'activation': ['tanh', 'relu'],
    'solver': ['sgd', 'adam'],
    'learning_rate': ['constant', 'invscaling'],
    'batch_size': [32, 64],
    'max_iter': [250]  
}

print("\nRunning hyperparameter tuning with GridSearchCV (this may take a minute)...")
mlp = MLPClassifier(random_state=42)
grid_search = GridSearchCV(mlp, param_grid, cv=kf, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_scaled, y_train)

#Extract Optimized Model and Evaluate Performance
best_mlp = grid_search.best_estimator_
y_pred = best_mlp.predict(X_val_scaled)

print(f" Best Neural Network Hyperparameters: {grid_search.best_params_}")


#Rubric Metrics
accuracy = accuracy_score(y_val, y_pred)
precision = precision_score(y_val, y_pred, average='macro')
recall = recall_score(y_val, y_pred, average='macro')
f1 = f1_score(y_val, y_pred, average='macro')
kappa = cohen_kappa_score(y_val, y_pred)
cm = confusion_matrix(y_val, y_pred)

print(f"Accuracy:  {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1 Score:  {f1:.4f}")
print(f"Kappa:     {kappa:.4f}\n")

print("Confusion Matrix:")
print(cm)

print("\nClassification Report:")
print(classification_report(y_val, y_pred))